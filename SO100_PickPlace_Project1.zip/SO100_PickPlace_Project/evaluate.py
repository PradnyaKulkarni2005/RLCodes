# Directory: SO100_PickPlace_Project/evaluate.py
from stable_baselines3 import PPO
from so100_env.so100_env import SO100PickEnv
import time

model = PPO.load("models/ppo_so100")
env = SO100PickEnv(render_mode=True)
obs = env.reset()

done = False
while not done:
    action, _ = model.predict(obs)
    obs, reward, done, info = env.step(action)
    time.sleep(0.02)

env.close()

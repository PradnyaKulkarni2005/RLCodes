# Directory: SO100_PickPlace_Project/so100_env/constants.py
# Placeholder

ACTION_SCALE = 0.05
# Directory: SO100_PickPlace_Project/so100_env/object_utils.py
# Placeholder

def random_object_position():
    return [0.3, 0.0, 0.02]

import numpy as np

def compute_reward(end_effector_pos, object_pos, goal_pos, object_lifted):
    """
    Compute a shaped reward for the pick and place task.

    Parameters:
    - end_effector_pos: tuple or np.array of shape (3,), current EE position
    - object_pos: tuple or np.array of shape (3,), current object position
    - goal_pos: tuple or np.array of shape (3,), desired place position
    - object_lifted: bool, True if object is off the ground

    Returns:
    - reward: float
    - done: bool
    """
    # Convert tuples to NumPy arrays
    end_effector_pos = np.array(end_effector_pos)
    object_pos = np.array(object_pos)
    goal_pos = np.array(goal_pos)

    # Distance-based reward to the object
    reach_dist = np.linalg.norm(end_effector_pos - object_pos)
    reward = -reach_dist  # encourage minimizing distance to object

    # If close to object
    if reach_dist < 0.1:
        reward += 1.0  # bonus for reaching

    # If lifted
    if object_lifted:
        reward += 2.0

        # Check if close to goal
        place_dist = np.linalg.norm(object_pos - goal_pos)
        if place_dist < 0.1:
            reward += 5.0  # big bonus for correct placement
            return reward, True

    return reward, False

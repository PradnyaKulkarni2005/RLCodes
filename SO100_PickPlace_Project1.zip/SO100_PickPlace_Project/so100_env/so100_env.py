# # Directory: SO100_PickPlace_Project/so100_env/so100_env.py
# import gym
# from gym import spaces
# import pybullet as p
# import pybullet_data
# import numpy as np
# import os
# import time
# from .reward_utils import compute_reward

# class SO100PickEnv(gym.Env):
#     def __init__(self, render_mode=False):
#         super(SO100PickEnv, self).__init__()
#         self.render_mode = render_mode
#         if self.render_mode:
#             p.connect(p.GUI)
#         else:
#             p.connect(p.DIRECT)

#         p.setAdditionalSearchPath(pybullet_data.getDataPath())
#         p.setGravity(0, 0, -9.8)

#         self.robot = None
#         self.obj = None
#         self.goal_position = [0.0, 0.3, 0.05]  # Adjusted Z height to match block

#         self.action_space = spaces.Box(low=-1, high=1, shape=(4,), dtype=np.float32)
#         self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(10,), dtype=np.float32)

#     def reset(self):
#         p.resetSimulation()
#         p.setGravity(0, 0, -9.8)
#         p.loadURDF("plane.urdf")

#         robot_urdf = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "assets", "so100", "so100.urdf"))
#         block_urdf = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "assets", "objects", "block.urdf"))

#         # Load robot and block
#         self.robot = p.loadURDF(robot_urdf, basePosition=[0, 0, 0.1], useFixedBase=True)
#         self.obj = p.loadURDF(block_urdf, basePosition=[0.3, 0, 0.05])

#         # Optionally reset joint states if needed (for multi-joint robot)
#         # for joint_index in range(p.getNumJoints(self.robot)):
#         #     p.resetJointState(self.robot, joint_index, targetValue=0)

#         return self._get_observation()

#     def step(self, action):
#         # TODO: Add joint control logic here
#         p.stepSimulation()

#         reward, done = compute_reward(
#             end_effector_pos=self.get_ee_position(),
#             object_pos=self.get_object_position(),
#             goal_pos=self.goal_position,
#             object_lifted=self.check_if_object_lifted()
#         )

#         obs = self._get_observation()
#         info = {}
#         return obs, reward, done, info

#     def get_ee_position(self):
#         # Replace with actual end-effector link index if known
#         ee_index = p.getNumJoints(self.robot) - 1
#         pos, _ = p.getLinkState(self.robot, ee_index)[:2]
#         return pos

#     def get_object_position(self):
#         pos, _ = p.getBasePositionAndOrientation(self.obj)
#         return pos

#     def check_if_object_lifted(self):
#         return self.get_object_position()[2] > 0.08  # A bit more than initial height

#     def _get_observation(self):
#         # Replace with meaningful observation: joint states, object position, etc.
#         robot_pos, _ = p.getBasePositionAndOrientation(self.robot)
#         object_pos = self.get_object_position()
#         ee_pos = self.get_ee_position()
#         return np.array(robot_pos + object_pos + ee_pos)

#     def render(self, mode='human'):
#         time.sleep(1. / 240.)

#     def close(self):
#         p.disconnect()
# Directory: SO100_PickPlace_Project/so100_env/so100_env.py
import gym
from gym import spaces
import pybullet as p
import pybullet_data
import numpy as np
import os
import time
from .reward_utils import compute_reward

class SO100PickEnv(gym.Env):
    def __init__(self, render_mode=False):
        super(SO100PickEnv, self).__init__()
        self.render_mode = render_mode
        if self.render_mode:
            p.connect(p.GUI)
        else:
            p.connect(p.DIRECT)

        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        p.setGravity(0, 0, -9.8)

        self.robot = None
        self.obj = None
        self.goal_position = [0.0, 0.3, 0.05]  # Adjusted Z height to match block

        self.action_space = spaces.Box(low=-1, high=1, shape=(1,), dtype=np.float32)  # One joint for now
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(9,), dtype=np.float32)

    def reset(self):
        p.resetSimulation()
        p.setGravity(0, 0, -9.8)
        p.loadURDF("plane.urdf")

        robot_urdf = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "assets", "so100", "so100.urdf"))
        block_urdf = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "assets", "objects", "block.urdf"))

        self.robot = p.loadURDF(robot_urdf, basePosition=[0, 0, 0.1], useFixedBase=True)
        self.obj = p.loadURDF(block_urdf, basePosition=[0.3, 0, 0.05])

        return self._get_observation()

    def step(self, action):
        # Move joint1 (assumed joint index 0)
        p.setJointMotorControl2(
            bodyIndex=self.robot,
            jointIndex=0,
            controlMode=p.POSITION_CONTROL,
            targetPosition=float(action[0]),
            force=10
        )

        p.stepSimulation()

        reward, done = compute_reward(
            end_effector_pos=self.get_ee_position(),
            object_pos=self.get_object_position(),
            goal_pos=self.goal_position,
            object_lifted=self.check_if_object_lifted()
        )

        obs = self._get_observation()
        return obs, reward, done, {}

    def get_ee_position(self):
        ee_index = p.getNumJoints(self.robot) - 1
        pos, _ = p.getLinkState(self.robot, ee_index)[:2]
        return pos

    def get_object_position(self):
        pos, _ = p.getBasePositionAndOrientation(self.obj)
        return pos

    def check_if_object_lifted(self):
        return self.get_object_position()[2] > 0.08

    def _get_observation(self):
        robot_pos, _ = p.getBasePositionAndOrientation(self.robot)
        object_pos = self.get_object_position()
        ee_pos = self.get_ee_position()
        return np.array(robot_pos + object_pos + ee_pos)

    def render(self, mode='human'):
        time.sleep(1. / 240.)

    def close(self):
        p.disconnect()

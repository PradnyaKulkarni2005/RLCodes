# from so100_env.so100_env import SO100PickEnv

# env = SO100PickEnv(render_mode=True)
# obs = env.reset()

# for _ in range(500):
#     action = env.action_space.sample()
#     obs, reward, done, info = env.step(action)
#     if done:
#         obs = env.reset()

# env.close()
import time
from so100_env.so100_env import SO100PickEnv

env = SO100PickEnv(render_mode=True)
obs = env.reset()

for _ in range(1000):
    action = env.action_space.sample()
    obs, reward, done, info = env.step(action)
    env.render()
    time.sleep(1. / 240.)

env.close()

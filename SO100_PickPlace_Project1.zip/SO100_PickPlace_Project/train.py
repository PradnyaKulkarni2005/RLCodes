# Directory: SO100_PickPlace_Project/train.py
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.callbacks import CheckpointCallback
import os
from so100_env.so100_env import SO100PickEnv

log_dir = "logs/ppo_run"
os.makedirs(log_dir, exist_ok=True)

env = Monitor(SO100PickEnv(render_mode=False), log_dir)

model = PPO("MlpPolicy", env, verbose=1, tensorboard_log=log_dir)
model.learn(total_timesteps=100_000)

model.save("models/ppo_so100")
import matplotlib.pyplot as plt
import pandas as pd

def plot_rewards(log_path):
    data = pd.read_csv(log_path)
    plt.plot(data['reward'])
    plt.xlabel("Episode")
    plt.ylabel("Reward")
    plt.title("Training Reward over Time")
    plt.show()
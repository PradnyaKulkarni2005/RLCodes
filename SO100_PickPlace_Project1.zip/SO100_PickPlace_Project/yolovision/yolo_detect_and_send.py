# yolovision/yolo_detect_and_send.py
from ultralytics import YOLO
import cv2
import socket  # For real robot communication
import time

def send_coordinates(x, y, host='127.0.0.1', port=9999):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((host, port))
            message = f"{x},{y}\n"
            s.sendall(message.encode())
    except Exception as e:
        print("[ERROR] Failed to send data:", e)

model = YOLO("yolov8n.pt")  # Replace with custom trained model
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    results = model(frame)
    for result in results:
        boxes = result.boxes.xyxy.cpu().numpy()
        for box in boxes:
            x1, y1, x2, y2 = map(int, box[:4])
            cx = (x1 + x2) // 2
            cy = (y1 + y2) // 2

            send_coordinates(cx, cy)
            cv2.circle(frame, (cx, cy), 5, (0, 255, 0), -1)

    cv2.imshow("YOLO Detection", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
